WPanorama - Panoramic picture
=============================
To install, simply unzip this archive
into your WPanorama pictures directory.
(by default: "WPanorama" subfolder
of "My documents" or "Documents")